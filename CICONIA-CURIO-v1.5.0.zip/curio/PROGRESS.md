# Progress — v1.5.0

## Implemented

- Monochrome white/grey/charcoal interface, original restrained teal/amber atmosphere with dense static local grain behind the rack, and a stable translucent preview with decorative fluting away from imagery/text. The supplied main logo and all asset files are unchanged. No reference image or watermark is used.
- 24 short cartons: consistently charcoal jewellery and light-grey toys. Matte fibre bump and roughness maps, small cut-edge bevels, folded lids, front and side seams, clipped shorter hanging tabs, and additional toy tuck tabs. A separate curved steel hook wraps the circular rail and crosses the actual die-cut slot at the fixed swing attachment. The hook stays on the rail while the carton swings around its slot centre.
- Existing rack motion configuration and input state machine retained: 250ms deliberate hold, 8px drag threshold, 140ms wheel quiet interval, 380ms settling, actual sector positions, fixed browsing camera and damped swing. Reduced-motion users KEEP the genuine 3D carousel; nonessential transitions/swing are suppressed. WebGL failure alone enables the list fallback.
- Independent product-list search across names/descriptions, All/Jewellery/Toys category filter, featured/name/price sorting, result counts, clear filters and no-results state. Unknown prices sort last without fabricated values. List operations do not rearrange the rack; selection opens the exact product.
- Redesigned full product view: genuine foreground 3D carton, subdued inert rack, hidden preview, clear close control, a visible My box receptacle and drag cue, matching target bounds/hit testing, restrained ready state and foreground canvas above target surfaces. Opening/closing dialogs, preview changes, list updates and replenishment use short transitions; reduced motion remains functional.
- Valid drag saves ONE unit, confirms the save and replenishes the carton while details stay OPEN. Repeated drags work without reopening. Invalid/cancelled drops save nothing. Grabbed-point constraint and limited damped rotation retained.
- Separate next-button quantity (default 1, bounds 1–99), per-product saved counter, and header aggregate quantity. Button saves its selected amount once and keeps details open. Undo subtracts the latest action's actual added amount, including a multi-unit action or a capped save. Existing grouped rows, +/−/remove, stable IDs, browser storage, unavailable rows and malformed-storage handling remain.
- No owner dashboard, authentication, backend, checkout, orders or reservations. Product/shop content remains consistently numbered placeholders.

## Validation

- Production build, applicable type and rendering/UI syntax checks, and four existing mechanics/storage tests pass.
- Chromium browser suite covers 1440, 768 and 390px: sectors/fixed camera, free drag/hold/resume/wheel settling, tapped product identity during settling, exact angle restoration, preview/category matching, grabbed-point error below 1e-6, invalid/cancelled drop, repeated one-unit saves, multi-unit button save and per-action Undo, saved counters, refresh persistence, My box +/− controls, combined list controls/no-results/reset, description search and keyboard selection, and horizontal overflow.
- Geometry diagnostics sample the actual hook curve: tangent rail contact without penetration and positive slot margin, attachment crossing error under .005 world units, and exactly two consistent category finishes. Front/side/rear attachment views are inspected, including opposite permitted swing extremes. These checks verify geometry rather than claiming physical hardware testing.
- Reduced-motion rendering and functional WebGL-fallback saving are checked. Desktop and mobile screenshots inspected.
- Embedded standalone document runs with networking disabled, renders 24 3D cartons and supports quantity saving, persistent-open details, Undo and closing without JavaScript errors. Direct file navigation is blocked by this managed browser's policy; opening the downloaded HTML by double-click in an unrestricted local browser remains a user check.

## Limitations

Real iOS/Android touch scrolling, physical trackpad feel, Safari/Firefox and lower-powered GPU performance are not established by Chromium automation. Browser-local storage may be restricted for local files and does not sync between devices. Product imagery, actual prices and shop details remain owner placeholders. No code substitutes invented details.

## Delivery

CICONIA-CURIO-v1.5.0.html embeds local modules, logos, fonts and assets; no runtime CDN or server is needed. CICONIA-CURIO-v1.5.0.zip contains editable source, lockfile, documentation, tests and the standalone file. Previous releases are preserved.
