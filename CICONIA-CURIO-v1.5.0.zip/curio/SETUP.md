# Cloud startup

Use the existing /workspace/website/curio directory; cloud tasks are isolated, so do not create another worktree unless requested. When absent, extract CICONIA-CURIO-v1.5.0.zip. Node.js 22+, npm, Python 3 and Chromium are required. Run npm ci --cache /tmp/curio-npm-cache --no-audit --no-fund, then npm run build. Use HOST=127.0.0.1 npm run dev for source development, or npm start for the built server. Start a fresh process after environment restoration. No secrets or database are needed.

Run npm test, npm run typecheck, npm run check and npm run build. With the source server on port 3000, run /workspace/curio-tools/bin/python tests/browser.py (Python Playwright and /usr/bin/chromium). Packaging uses npm run standalone then python3 scripts/package.py. These create versioned HTML and ZIP files beside curio; preserve previous releases.
