from playwright.sync_api import sync_playwright,expect
import os
URL=os.environ.get('CURIO_TEST_URL','http://127.0.0.1:3000')
def settled(page):
 page.wait_for_function('curioState().state === "idle"',timeout=5000)
def state(page):return page.evaluate('curioState()')
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--enable-unsafe-swiftshader'])
 for width in [1440,768,390]:
  page=browser.new_page(viewport={'width':width,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(URL);page.wait_for_function('window.curioState && curioState().boxes===24')
  initial=state(page);camera=initial['camera']
  geometry=page.evaluate('curioGeometry()');assert len(geometry)==24;assert all(g['slotMargin']>0 and -.001<g['railClearance']<.002 and g['attachmentError']<.005 for g in geometry);assert len({g['color'] for g in geometry if g['category']=='toys'})==1;assert len({g['color'] for g in geometry if g['category']=='jewellery'})==1;assert len({g['color'] for g in geometry})==2
  page.locator('[data-category=toys]').click();settled(page);assert state(page)['front']=='product-19';assert state(page)['boxes']==24;assert state(page)['camera']==camera
  page.locator('[data-category=jewellery]').click();settled(page);assert state(page)['front']=='product-7'
  page.locator('#scene').focus();page.keyboard.press('ArrowRight');settled(page);assert state(page)['front']=='product-8';assert state(page)['preview']=='product-8'
  # Drag stays free while held; hold after movement is an ordinary drag release.
  box=page.locator('#scene').bounding_box();x=box['x']+box['width']*.5;y=box['y']+box['height']*.55
  page.mouse.move(x,y);page.mouse.down();page.mouse.move(x+32,y,steps=4);page.wait_for_timeout(300);assert state(page)['state']=='dragging';a=state(page)['angle'];page.wait_for_timeout(200);assert abs(state(page)['angle']-a)<1e-9;page.mouse.up();settled(page)
  # Stationary hold suppresses opening and snapping; movement after a hold resumes.
  page.mouse.move(x,y);page.mouse.down();page.wait_for_timeout(320);a=state(page)['angle'];assert state(page)['state']=='held';page.mouse.up();page.wait_for_timeout(450);assert abs(state(page)['angle']-a)<1e-9;assert not page.locator('#product-dialog').is_visible()
  page.mouse.down();page.wait_for_timeout(300);page.mouse.move(x+35,y,steps=3);assert state(page)['state']=='dragging';page.mouse.up();settled(page)
  # Wheel input cancels a settle and settles only after quiet.
  page.mouse.move(x,y);page.mouse.wheel(0,80);page.wait_for_timeout(60);page.mouse.wheel(0,40);page.wait_for_timeout(250);settled(page)
  # Tap during settling opens the originally pressed item.
  page.locator('#next').click();page.wait_for_timeout(50);moving=state(page);center=next(c for c in moving['centers'] if c['id']==moving['front']);page.mouse.click(center['x'],center['y']);expect(page.locator('#product-dialog')).to_be_visible();assert state(page)['focus']==state(page)['lastPressedProduct'];page.keyboard.press('Escape');expect(page.locator('#product-dialog')).not_to_be_visible()
  # Exact front box raycast, and exact angle restoration.
  page.locator('#scene').focus();page.keyboard.press('Home');settled(page);a=state(page)['angle'];front=state(page)['front'];center=next(c for c in state(page)['centers'] if c['id']==front);page.mouse.click(center['x'],center['y']);expect(page.locator('#product-dialog')).to_be_visible();assert state(page)['focus']==front
  page.wait_for_timeout(250)
  # Grabbed point remains attached to anchor, invalid drop saves nothing.
  c=state(page)['view']['center'];page.mouse.move(c['x']+8,c['y']+12);page.mouse.down();page.mouse.move(c['x']+35,c['y']+20,steps=6);page.wait_for_timeout(150);assert state(page)['view']['dragging'];assert state(page)['view']['anchorError']<1e-6;page.mouse.up();page.wait_for_timeout(350);assert state(page)['total']==0
  # Drag to right target adds exactly once and restores angle.
  c=state(page)['view']['center'];r=page.locator('#detail-image').bounding_box();page.mouse.move(c['x'],c['y']);page.mouse.down();page.mouse.move(r['x']+r['width']*.85,r['y']+r['height']*.5,steps=12);assert state(page)['view']['overTarget'];page.mouse.up();expect(page.locator('#product-dialog')).to_be_visible();assert state(page)['total']==1;page.wait_for_timeout(650);assert not state(page)['view']['dragging'];assert abs(state(page)['angle']-a)<1e-9
  # Repeated drag remains possible without reopening.
  c=state(page)['view']['center'];page.mouse.move(c['x'],c['y']);page.mouse.down();page.mouse.move(r['x']+r['width']*.85,r['y']+r['height']*.5,steps=12);page.mouse.up();assert state(page)['total']==2;page.wait_for_timeout(650);page.locator('#undo').click();assert state(page)['total']==1
  # Quantity selector controls one button action and Undo reverses its amount.
  page.locator('#quantity-plus').click();page.locator('#quantity-plus').click();page.locator('#detail-add').click();assert state(page)['total']==4;expect(page.locator('#product-dialog')).to_be_visible();expect(page.locator('#saved-total')).to_contain_text('4');page.locator('#undo').click();assert state(page)['total']==1
  # Cancellation never saves.
  c=state(page)['view']['center'];page.mouse.move(c['x'],c['y']);page.mouse.down();page.mouse.move(r['x']+r['width']*.85,r['y']+r['height']*.5,steps=6);page.locator('#detail-image').dispatch_event('pointercancel',{'pointerId':1});page.mouse.up();assert state(page)['total']==1;page.wait_for_timeout(350)
  page.keyboard.press('Escape');expect(page.locator('#product-dialog')).not_to_be_visible();assert abs(state(page)['angle']-a)<1e-9
  page.locator('#add').click();assert state(page)['total']==2;page.locator('#undo').click();assert state(page)['total']==1
  page.reload();page.wait_for_function('window.curioState && curioState().boxes===24');assert state(page)['total']==1
  page.locator('#my-box').click();expect(page.locator('#box-items')).to_contain_text('[product1]');page.get_by_role('button',name='Increase [product1]',exact=True).click();assert state(page)['total']==2;page.get_by_role('button',name='Decrease [product1]',exact=True).click();assert state(page)['total']==1;page.keyboard.press('Escape');expect(page.locator('#box-dialog')).not_to_be_visible()
  # Independent product-list filters never move the rack.
  before=state(page)['angle'];page.locator('#list-view summary').click();page.locator('#list-category').select_option('toys');page.locator('#list-search').fill('description18');expect(page.locator('#list-count')).to_have_text('1 of 24 products');page.locator('#list-sort').select_option('high');expect(page.locator('#price-note')).to_be_visible();assert state(page)['angle']==before;page.locator('#list-search').fill('unfindable');expect(page.locator('#list-empty')).to_be_visible();page.locator('#list-reset').click();expect(page.locator('.list-product')).to_have_count(24);page.locator('#list-view summary').click()
  # Search description as well as name, keyboard selection and preserved search angle.
  page.locator('#search').fill('description18');expect(page.locator('#suggestions')).to_contain_text('[product18]');page.locator('#search').press('ArrowDown');page.locator('#search').press('Enter');expect(page.locator('#detail-title')).to_have_text('[product18]');saved=state(page)['angle'];page.keyboard.press('Escape');assert abs(state(page)['angle']-saved)<1e-9
  expect(page.locator('#product-dialog')).not_to_be_visible();page.locator('#search').fill('unfindable');expect(page.locator('#suggestions')).to_contain_text('No products found');page.locator('#clear-search').click()
  page.locator('#details').click();page.locator('#detail-add').click();expect(page.locator('#product-dialog')).to_be_visible();assert state(page)['total']==2;page.keyboard.press('Escape');expect(page.locator('#product-dialog')).not_to_be_visible()
  page.evaluate('scrollTo(0,0)');assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');page.screenshot(path=f'/tmp/curio-v14-{width}.png',full_page=True)
  assert not errors,errors;print('PASS',width,'hook/slot clearances, category finishes, sectors, fixed camera, input states, moving tap, grabbed anchor, repeated drag/save, quantity actions, Undo, reload, list controls, search, overflow',flush=True);page.close()
 # Reduced motion and WebGL fallback.
 page=browser.new_page(reduced_motion='reduce');page.goto(URL);assert state(page)['boxes']==24;page.locator('#next').click();page.wait_for_function('curioState().front === "product-2"');assert all(v==0 for v in state(page)['swing']);print('PASS reduced motion',flush=True);page.close()
 page=browser.new_page();page.add_init_script("const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(type,...args){return type.includes('webgl')?null:original.call(this,type,...args)}");page.goto(URL);expect(page.locator('#scene')).to_contain_text('3D is unavailable');expect(page.locator('#list-view')).to_have_attribute('open','');page.locator('.list-product').first.click();expect(page.locator('#detail-title')).to_have_text('[product1]');page.locator('#detail-add').click();expect(page.locator('#bag-count')).to_have_text('1');print('PASS WebGL fallback and functional saving',flush=True);browser.close()
