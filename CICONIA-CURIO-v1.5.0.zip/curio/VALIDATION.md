# Validation

In curio/, run npm test, npm run typecheck, npm run check and npm run build. Start npm run dev, then run python3 tests/browser.py with Python Playwright and /usr/bin/chromium. CURIO_TEST_URL can select another source or production origin.

Generate the embedded release using npm run standalone and test it with python3 tests/standalone.py. This loads the generated document with networking disabled; managed Chromium policy blocks direct file:// navigation. Then run python3 scripts/package.py to produce the source ZIP and verify its integrity. See PROGRESS.md for scope and physical-device limitations.
