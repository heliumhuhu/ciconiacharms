# CICONIA CURIO — working brief

## Scope and precedence

Implement the owner's original 21-part mechanics specification through Stage 3. The owner explicitly deferred the owner dashboard after requesting all stages. Preserve the later visual refinements: 24 shorter cartons, a wider rack reaching the left desktop edge, the supplied main logo unchanged, recovered historical marks, monochrome-led white/grey/black palette with restrained teal/amber atmospheric accents, physical paperboard, and minimal copy. These replace the older 12-product starting count, black/white carton palette, full-rack desktop margin and pastel colour recommendations. Keep product content as consistently numbered placeholders until supplied.

## 1. Purpose

A physical jewellery and toy shop. Browse products and save quantities for a visit. No checkout, payments, delivery, orders or reservations. Use “Browse here · Buy in store”, “My box — saved favourites” and “Saved for your visit. Items are not reserved.” Use original supplied logos. Address, opening hours and contact remain editable placeholders.

## 2–4. Presentation

Light, modern, minimal; readable contrast and focus, restrained borders and shadows, a secondary translucent preview card and no unnecessary slogans. Use one static, densely stippled local gradient behind the rack, fading seamlessly into the page and never over text or photographs. Transparent 3D canvas. Header logo and total My box quantity; coherent search/category controls; large rack left, compact preview right; mobile preview below. Footer shop details and in-store message.

## 5–7. Geometry and framing

Genuine perspective Three.js geometry, never billboards, CSS substitutes, videos or a flat carousel. Fixed, gently elevated frontal camera. Circular metal rail, central pole, supporting spokes, attached curved black hooks. No base. Boxes have six physical surfaces, shallow depth, small bevels, paper fibres, roughness, folded lids/seams and readable edges. Fronts face radially outward; true occlusion and visible side faces. Product photographs on fronts only, with preserved aspect ratio. Jewellery and Toys each occupy one 180-degree sector even with unequal counts. Compute positions and snap targets from actual sector angles. Short boxes swing from attachment points with restrained damping; no detachment or perpetual wobble. Desktop rack reaches the left edge per latest request. Mobile frames the front arc rather than shrinking the entire rack; every item remains reachable. No horizontal page overflow.

## 8–10. Rack interaction

Central motion configuration. Elapsed-time motion. Active drag/wheel input is free with no snap attraction and interrupts previous commands. Ordinary release settles to nearest actual position with minimal inertia and no bounce. Wheel waits for quiet (140ms current tuning), then settles in 380ms. No added wheel momentum. Hold threshold 250ms; drag threshold 8px. Pointer-down pauses and records the exact hit product and angle. Quick tap opens that product. Stationary deliberate hold-release stays exactly stopped indefinitely and opens nothing. Moving after a hold becomes ordinary drag and settles on release. Handle capture, release outside, cancellation and lost capture; cancelled gestures never open/save. Preserve zoom and vertical touch scrolling. Explicit states keep pressed, held, dragging, wheel, settling and focus separate. Category selection interrupts and takes the shortest rotation to near its sector centre. Manual rotation updates category display without issuing new commands.

## 11. Preview

Frontmost by angular distance from fixed viewing direction, with switching tolerance and brief crossfade. Image, name, price and More details. Stable dimensions. Hide during full view. Numbered placeholders remain linked everywhere. Real prices use integer pence formatted GBP.

## 12–14. Full view and saving

Preserve exact browsing angle. Enlarge a genuine 3D carton in the foreground on the left with readable HTML details, subdued/inert rack and hidden preview. Keep right side available as saving target. Close button, Escape and accessible save button. Close restores the exact angle without snapping or resuming movement. Mobile stacks content. On grab, the exact raycast point becomes a moving anchor; it follows the pointer on a fixed interaction plane and the box swings gently around that point. Limit rotation and damp return. Reveal “Release to add to My box” while dragging; indicate a valid right-hand target. Valid release adds exactly one, briefly falls away and replenishes, confirms the save and updates a separate per-product saved total. Details stay open for repeated saves. Invalid release adds nothing and returns home. Cancel never saves. A secondary button adds its selected quantity (1–99, default 1); accessible minus/plus controls sit beside it. Both methods keep details open. Undo reverses the entire latest action’s added amount, preserving earlier units. Saving never removes the rack product.

## 15. My box

Stable IDs and quantities in localStorage on the same browser/device. Repeated saves increment. Group rows with image, name, unit price, quantity, minus, plus and remove. Header sums quantities. Undo reverses the latest addition only. Handle invalid/unavailable storage. Hidden/deleted saved IDs remain unavailable rows rather than replacement items. Do not imply cross-device sync or stock reservation.

## 16–17. Search and content

Search names and descriptions across both categories; accessible suggestions with image, name and price, keyboard arrows/Enter/Escape, clearing and no-results state. Selection rotates to the actual product, opens it, and close returns to that position. Separate editable content from geometry: stable ID, category, description, integer-pence price (null only for explicit owner placeholders), image path/alt, display order and visibility. Support long text, missing images and unequal counts. Use local placeholders, no random remote images or invented shop facts.

## 18. Owner dashboard — deferred by owner

Future stage: Supabase or equivalent, owner authentication, product/image CRUD, ordering/visibility, shop details. Server-enforced published-only public reads and explicit-owner writes/uploads. No hidden-URL or frontend password security, no all-authenticated write access, no privileged browser keys. Supply schema, migrations, storage/database policies, safe environment example and deployment instructions when this stage is requested. Production remote-data failures must be shown honestly; never silently replace them with samples.

## 19. Accessibility/performance

HTML controls/text, keyboard rack navigation, visible focus, focus-managed dialogs, accessible notifications, alternative list, reduced motion, loading/image errors and WebGL fallback. Reduced motion removes swing/coasting/falling while retaining function. Local static noise. Limit mobile resolution; stop animation when settled; dispose resources. Avoid bloom and expensive postprocessing. Reuse carton geometry where feasible. Browser tests cannot substitute for real touch/trackpad acceptance.

## 20–21. Delivery and acceptance

Preserve relevant existing work, stable compatible dependencies and lockfile. Stages 1–3 are authorized; dashboard deferred. Keep this brief and PROGRESS.md. Deliver downloadable standalone HTML plus source ZIP on GitHub. Verify true perspective/thickness/fixed camera; no snapping under active input; hold/drag/tap rules; matching preview; interrupted category changes; exact close angle; grabbed-point constraint; invalid/valid saves; quantities, Undo and refresh persistence; visible non-obstructive grain. Check 390, 768 and 1440px. Run build, applicable type checks and meaningful automated tests; distinguish manual device checks.

## Owner update — release 1.5.0 (takes precedence)

Keep 24 short physical cartons, the wide rack, existing 250/8/140/380 motion settings and exact selection/angle restoration. One charcoal finish for jewellery; one light-grey finish for toys. Toy cartons use clipped tab shoulders and tuck tabs; both use matte fibres, roughness, bevelled cut edges, lid and glue seams. Short tags have real slots centred on the swing attachment; the separate steel hook wraps the rail and threads the slot.

White/grey/black interface with local static grain and restrained original teal/amber gradient fields only behind the rack. No reference image, watermark, sphere or pedestal is used. Fluting occupies the decorative edge of a stable translucent preview; image and text remain clear. Remove the decorative object count.

Product-list search, All/Jewellery/Toys filters, featured/name/price sorting, result count, reset and no-results state work independently of physical rack order. Unknown prices remain last, with an explanation only during price sorting. Opening an exact list result positions and opens that product.

The large 3D details carton, layered My box receptacle, drag cue and ready-to-release state make one-unit drag saving primary. The quantity selector affects only button additions. Keep details open after either method, replenish the carton, distinguish selected/saved/header totals, prevent duplicate gesture completion, and undo the actual last save amount. Invalid/cancelled drops add nothing.

Reduced-motion preferences MUST keep the 3D rack. Reduce nonessential animation and swing, retaining every browsing and saving operation. Only WebGL failure uses the list fallback. Main logo and numbered placeholders remain unchanged. Owner dashboard, authentication and backend remain deferred.
