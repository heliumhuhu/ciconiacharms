# CICONIA CURIO 1.5.0

Physical-shop browsing with a perspective 24-carton rack, two category sectors, free rotation, deliberate hold-stop, damped swing, short indexed settling, a full 3D product view, grabbed-point dragging, drag-to-save, quantities, Undo, persistent My box, keyboard search and an accessible list fallback. No checkout, orders or stock reservations. The owner dashboard is deferred by the owner.

## Open directly

Download **CICONIA-CURIO-v1.5.0.html** and open it in a modern browser with WebGL. Scripts, logos, fonts and textures are embedded. No server or installation is required. The product list and save button remain available if WebGL is unavailable. Browser storage policy may restrict persistence for local files; use the source server for a stable localhost origin when testing refresh persistence.

## Source development

Node.js 22+, npm and Python 3 for standalone packaging:

```sh
npm ci --cache /tmp/curio-npm-cache --no-audit --no-fund
npm run dev
```

Default port 3000; HOST and PORT are configurable. Production: `npm run build` then `npm start`. Start a new server process after environment restoration. No secrets or database are required for this local catalogue mode. Use the existing cloud checkout, not another Git worktree unless explicitly requested.

## Edit

- `public/products.js`: stable IDs, visibility, ordering, category, descriptions, image paths/alt and shop details. Real prices use integer `pricePence` and display in GBP. The owner's numbered placeholders use null price plus `[priceN]` until actual prices are supplied. Retain IDs when editing; unavailable saved IDs remain visible in My box.
- `public/motion-config.js`: hold/drag thresholds, wheel quiet time, settling, swing and category-position functions.
- `public/rack.js`: physical rack/cartons and explicit input states.
- `public/product-view.js`: foreground 3D carton, moving grab anchor, constrained swing and save target.
- `public/bag.js`: quantities and safe storage parsing, including migration of earlier saved IDs.
- `public/boutique.js`: accessible HTML UI, search, My box, notifications and Undo.
- `public/boutique.css` and `public/index.html`: presentation and controls.

Image proportions are preserved. Missing images show a labelled fallback. The original uploaded rack logo is unchanged. Historical SVG marks are from Git commit 83f53e2. The 24-box count, short cartons, near-left-edge wide rack and monochrome-led design follow current owner requirements.

## Checks and packaging

```sh
npm test
npm run typecheck
npm run check
npm run build
python3 tests/browser.py
npm run standalone
```

Browser tests need Python Playwright and `/usr/bin/chromium`, and the dev server running. Set `CURIO_TEST_URL` to test another origin. TypeScript checks the JS data, bag and motion modules; syntax checks cover rendering and UI modules. Browser checks cover actual interactive behavior. See PROGRESS.md for evidence and remaining real-device checks.

`npm run standalone` writes the HTML next to the source folder. The generator embeds modules once using local Blob module URLs; it makes no runtime network requests. All vendored Three.js license text is retained.

## Release 1.5.0

Monochrome interface, charcoal jewellery cartons and light-grey toy cartons, shorter die-cut tags with rail hooks through their openings, a translucent preview and independent list search/category/sort controls. Unknown prices sort last. Details remain open after every save. Dragging saves one; the adjacent quantity selector controls button additions (1–99). The separate saved counter reports this product’s current quantity. Undo reverses only the latest completed save amount. My box retains grouped quantities and browser-local persistence.

Reduced-motion mode retains the genuine 3D carousel, with direct category positioning and no decorative swing. Only unavailable WebGL activates the list fallback. The supplied logo is unchanged. No checkout, reservation, backend or owner dashboard.
